package student;

public class StudentTest {
 /**
  * TODO: 
  * 	write at least 20 Junit test cases to test your implementation of ListDGraph;
  */
}
