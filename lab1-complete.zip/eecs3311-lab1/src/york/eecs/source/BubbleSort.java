package york.eecs.source;

import java.util.ArrayList;
import java.util.Map;

/**
 * @author song and you
 * @description: @BubbleSort uses bubble sorting algorithm to rank a map based on the values.
 */
public class BubbleSort implements MapSort<String, Integer>{
    /**
     * @map to be sorted;
     */
	public Map<String, Integer> map;
    
	
	@Override
	public ArrayList<String> sortbyValue(){
	
		ArrayList<String> listKey = new ArrayList<>();
		ArrayList<Integer> listVal = new ArrayList<>();
		
        listKey.addAll(map.keySet());
        
        for(int i =0;i<listKey.size();i++) {
        	listVal.add(map.get(listKey.get(i)));
        }
        
        
        String temp;
        int val;
        boolean sorted = false;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < listVal.size()-1; i++) {
                if (listVal.get(i).compareTo(listVal.get(i + 1)) > 0) {
                	
                    temp = listKey.get(i);
                    val = listVal.get(i);
                    
                    listKey.set(i, listKey.get(i + 1));
                    listVal.set(i, listVal.get(i + 1));
                    
                    listKey.set(i + 1, temp);
                    listVal.set(i + 1, val);
                    
                    sorted = false;
                }
            }
        }

        return listKey;
	}

	public void setMap(Map<String, Integer> map_to_be_sorted)throws MapContainsNullValueException {
		map =  map_to_be_sorted;
		for(String st:  map_to_be_sorted.keySet()) {
			if (map_to_be_sorted.get(st) == null) {
		        throw new MapContainsNullValueException("Map Contains Null value");
		    }
			
		}
		

		
		
	}

	public Map<String, Integer> getMap() {
		
		return this.map;
	}
}