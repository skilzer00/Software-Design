package york.eecs.source;

import java.util.ArrayList;
import java.util.Map;

/**
 * @author song and you
 * @description: @HeapSort uses max heap algorithm to rank a map based on the values.
 */
public class HeapSort implements MapSort<String, Double>{
	/**
     * @map to be sorted;
     */	
	public Map<String, Double> map;
    
	/**
	 * TODO: There are missing methods, you can find clues of these methods from test cases.
     */
	
	
	/**
	 * @description: Sort a map by the values in ascending order max heap sorting algorithm.
	 * @return: Return the corresponding key list of the sorted map.
	 */
	@Override
	public ArrayList<String> sortbyValue() {
		/**
		 *  TODO: Implement sorting the maps by values with max heap sorting algorithm.
		 *  	  This method returns the corresponding key list.
		 *  	  You need to use the auxiliary method, i.e., @heapify.
		 */
		
		
int size = map.size();
		
		String[] keyArr = new String[size];
		double[] valArr = new double[size];
		int index = 0;
		for(String st:map.keySet()) {
			keyArr[index]=st;
			valArr[index]=map.get(st);
			index++;
		}
			


        for (int i = size / 2 - 1; i >= 0; i--)
            heapify(keyArr,valArr, size, i);
 

        for (int i = size - 1; i > 0; i--) {

            String  tempKey = keyArr[0];
            keyArr[0] = keyArr[i];
            keyArr[i] = tempKey;
 
            double tempVal = valArr[0];
            valArr[0] = valArr[i];
            valArr[i]=tempVal;
            
            
            heapify(keyArr,valArr, i, 0);
        }
        ArrayList<String> list = new ArrayList<>();
        
        for(String ss: keyArr) {
        	list.add(ss);
        }
		
		return list;
	}
	

	public void heapify(String[] keyArr, double[] valArr, int n, int i) {
		
		 int largest = i; 
	        int l = 2 * i + 1; 
	        int r = 2 * i + 2; 
	 
	       
	        if (l < n && valArr[l] > valArr[largest])
	            largest = l;
	 
	      
	        if (r < n && valArr[r] > valArr[largest])
	            largest = r;
	 
	       
	        if (largest != i) {
	            double swapVal = valArr[i];
	            valArr[i] = valArr[largest];
	            valArr[largest] = swapVal;
	            
	            String swapKey = keyArr[i];
	            keyArr[i] = keyArr[largest];
	            keyArr[largest] = swapKey;
	 
	         
		
	            heapify(keyArr,valArr, n, largest);
	        }	
	
	}

	public void setMap(Map<String, Double> map_to_be_sorted)throws MapContainsNullValueException {
	
		map =  map_to_be_sorted;
		
		for(String st:  map_to_be_sorted.keySet()) {
			if (map_to_be_sorted.get(st) == null) {
		        throw new MapContainsNullValueException("Map Contains Null value");
		    }
			
		}

		
	}

	public Map<String, Double> getMap() {
		
		return map;
	}
}