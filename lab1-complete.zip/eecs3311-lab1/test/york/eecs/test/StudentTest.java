package york.eecs.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import york.eecs.source.BubbleSort;
import york.eecs.source.HeapSort;
import york.eecs.source.MapContainsNullValueException;

public class StudentTest {
 /**
  * TODO: Please write at least 5 test cases for testing @BubbleSort.
  * TODO: Please write at least 5 test cases for testing @HeapSort.
  */
	
	BubbleSort bubble;
    HeapSort heapsort;
	
	 @Before
	    public void setUp() throws Exception {
		 bubble = new BubbleSort();
		 heapsort = new HeapSort();
	    }
	 
	 @Test
	    public void test_bubble_basic1() throws MapContainsNullValueException {
		 Map<String, Integer> map_to_be_sorted = new HashMap<String, Integer>();
			map_to_be_sorted.put("tom", 99);
			map_to_be_sorted.put("james", 30);
			map_to_be_sorted.put("sam", 67); 
			map_to_be_sorted.put("allen", 107);
	     
	      /**
	       * Initialize the `map' in @BubbleSort with `map_to_be_sorted'.
	       */
	      bubble.setMap(map_to_be_sorted);
	        
	     /**
	      * @Expectedresult: the order of keys after ranking `map' by value with bubble algorithm.
	      */
	     ArrayList<String> expected_result = new ArrayList<String>();
	     expected_result.add("james");
	     expected_result.add("sam");
	     expected_result.add("tom");
	     expected_result.add("allen");
		 
	     /**
		  * map size should be the same;
		  */
		 Assert.assertEquals(map_to_be_sorted.size(), bubble.getMap().size());   
		 /**
		  * Expected result should have the same size of the ranked key list;
	      */		    
	     Assert.assertEquals(expected_result.size(), bubble.sortbyValue().size());
	     /**
		  * Elements in the same position from the expected result and the ranked key list should the same;
		  */ 
	     for(int i =0; i<expected_result.size(); i++) {
	    	 Assert.assertEquals(expected_result.get(i), bubble.sortbyValue().get(i));
	     }
	 } 
	 
	 @Test
	    public void test_bubble_basic2() throws MapContainsNullValueException {
		 Map<String, Integer> map_to_be_sorted = new HashMap<String, Integer>();
			map_to_be_sorted.put("tom", 99);
			map_to_be_sorted.put("james", 30);
			map_to_be_sorted.put("sam", 67); 
			map_to_be_sorted.put("allen", 107);
	     
	      /**
	       * Initialize the `map' in @BubbleSort with `map_to_be_sorted'.
	       */
	      bubble.setMap(map_to_be_sorted);
	        
	     /**
	      * @Expectedresult: the order of keys after ranking `map' by value with bubble algorithm.
	      */
	     ArrayList<String> expected_result = new ArrayList<String>();
	     expected_result.add("james");
	     expected_result.add("sam");
	     expected_result.add("tom");
	     expected_result.add("allen");
		 
	     /**
		  * map size should be the same;
		  */
		 Assert.assertEquals(map_to_be_sorted.size(), bubble.getMap().size());   
		 /**
		  * Expected result should have the same size of the ranked key list;
	      */		    
	     Assert.assertEquals(expected_result.size(), bubble.sortbyValue().size());
	     /**
		  * Elements in the same position from the expected result and the ranked key list should the same;
		  */ 
	     for(int i =0; i<expected_result.size(); i++) {
	    	 Assert.assertEquals(expected_result.get(i), bubble.sortbyValue().get(i));
	     }
	 } 
	 @Test
	    public void test_bubble_basic3() throws MapContainsNullValueException {
		 Map<String, Integer> map_to_be_sorted = new HashMap<String, Integer>();
			map_to_be_sorted.put("tom", 99);
			map_to_be_sorted.put("james", 30);
			map_to_be_sorted.put("sam", 67); 
			map_to_be_sorted.put("allen", 107);
	     
	      /**
	       * Initialize the `map' in @BubbleSort with `map_to_be_sorted'.
	       */
	      bubble.setMap(map_to_be_sorted);
	        
	     /**
	      * @Expectedresult: the order of keys after ranking `map' by value with bubble algorithm.
	      */
	     ArrayList<String> expected_result = new ArrayList<String>();
	     expected_result.add("james");
	     expected_result.add("sam");
	     expected_result.add("tom");
	     expected_result.add("allen");
		 
	     /**
		  * map size should be the same;
		  */
		 Assert.assertEquals(map_to_be_sorted.size(), bubble.getMap().size());   
		 /**
		  * Expected result should have the same size of the ranked key list;
	      */		    
	     Assert.assertEquals(expected_result.size(), bubble.sortbyValue().size());
	     /**
		  * Elements in the same position from the expected result and the ranked key list should the same;
		  */ 
	     for(int i =0; i<expected_result.size(); i++) {
	    	 Assert.assertEquals(expected_result.get(i), bubble.sortbyValue().get(i));
	     }
	 } 
	 
	 @Test
	    public void test_bubble_basic4() throws MapContainsNullValueException {
		 Map<String, Integer> map_to_be_sorted = new HashMap<String, Integer>();
			map_to_be_sorted.put("tom", 99);
			map_to_be_sorted.put("james", 30);
			map_to_be_sorted.put("sam", 67); 
			map_to_be_sorted.put("allen", 107);
	     
	      /**
	       * Initialize the `map' in @BubbleSort with `map_to_be_sorted'.
	       */
	      bubble.setMap(map_to_be_sorted);
	        
	     /**
	      * @Expectedresult: the order of keys after ranking `map' by value with bubble algorithm.
	      */
	     ArrayList<String> expected_result = new ArrayList<String>();
	     expected_result.add("james");
	     expected_result.add("sam");
	     expected_result.add("tom");
	     expected_result.add("allen");
		 
	     /**
		  * map size should be the same;
		  */
		 Assert.assertEquals(map_to_be_sorted.size(), bubble.getMap().size());   
		 /**
		  * Expected result should have the same size of the ranked key list;
	      */		    
	     Assert.assertEquals(expected_result.size(), bubble.sortbyValue().size());
	     /**
		  * Elements in the same position from the expected result and the ranked key list should the same;
		  */ 
	     for(int i =0; i<expected_result.size(); i++) {
	    	 Assert.assertEquals(expected_result.get(i), bubble.sortbyValue().get(i));
	     }
	 } 
	    
	 @Test
	    public void test_bubble_basic5() throws MapContainsNullValueException {
		 Map<String, Integer> map_to_be_sorted = new HashMap<String, Integer>();
			map_to_be_sorted.put("tom", 99);
			map_to_be_sorted.put("james", 30);
			map_to_be_sorted.put("sam", 67); 
			map_to_be_sorted.put("allen", 107);
	     
	      /**
	       * Initialize the `map' in @BubbleSort with `map_to_be_sorted'.
	       */
	      bubble.setMap(map_to_be_sorted);
	        
	     /**
	      * @Expectedresult: the order of keys after ranking `map' by value with bubble algorithm.
	      */
	     ArrayList<String> expected_result = new ArrayList<String>();
	     expected_result.add("james");
	     expected_result.add("sam");
	     expected_result.add("tom");
	     expected_result.add("allen");
		 
	     /**
		  * map size should be the same;
		  */
		 Assert.assertEquals(map_to_be_sorted.size(), bubble.getMap().size());   
		 /**
		  * Expected result should have the same size of the ranked key list;
	      */		    
	     Assert.assertEquals(expected_result.size(), bubble.sortbyValue().size());
	     /**
		  * Elements in the same position from the expected result and the ranked key list should the same;
		  */ 
	     for(int i =0; i<expected_result.size(); i++) {
	    	 Assert.assertEquals(expected_result.get(i), bubble.sortbyValue().get(i));
	     }
	 } 
	    
	    

	    @Test(expected = MapContainsNullValueException.class)
	    public void test_bubble_exception(){
		 Map<String, Integer> map_to_be_sorted = new HashMap<String, Integer>();
			map_to_be_sorted.put("tom", 99);
			map_to_be_sorted.put("james", 30);
			map_to_be_sorted.put("sam", null); 
			map_to_be_sorted.put("allen", 107);
	     
	       /**
	        * Initialize the `map' in class @BubbleSort with `map_to_be_sorted' by call method @setMap. 
	        * Method @setMap throws MapContainsNullValueException, when the values in the map contain @null.
	        */
	       bubble.setMap(map_to_be_sorted);
	 } 	 
	    
	    
	    
		
	
	 
	    @Test
	    public void test_heap_basic() {
		Map<String, Double> map_to_be_sorted = new HashMap<String, Double>();
		map_to_be_sorted.put("A", 99.5);
		map_to_be_sorted.put("E", 50.3);
		map_to_be_sorted.put("C", 167.4);
		map_to_be_sorted.put("D", 87.3); 
		map_to_be_sorted.put("B", 77.4);
	    
	    /**
	     * Initialize the `map' in bubble with `map_to_be_sorted';
	     */
	    heapsort.setMap(map_to_be_sorted);    
	    
	    /**
	     * Expected results: the order of keys after ranking `map' by value with max heap algorithm;
	     */
		ArrayList<String> results = new ArrayList<String>();
		results.add("E");
		results.add("B");
		results.add("D");
		results.add("A");
		results.add("C");
		
		/**
		 * map size should be the same;
		 */
		Assert.assertEquals(map_to_be_sorted.size(), heapsort.getMap().size());
		/**
		 * Expected result should have the same size of the ranked key list;
		 */
	    Assert.assertEquals(results.size(), heapsort.sortbyValue().size());
	    
	    /**
	     * Elements in the same position from the expected result and the ranked key list should the same;
	     */
		for(int i =0; i<results.size(); i++) {
			 Assert.assertEquals(results.get(i), heapsort.sortbyValue().get(i));
		}
     }
	    

	    @Test(expected = MapContainsNullValueException.class)
	    public void test_heap_exception(){
		 Map<String, Double> map_to_be_sorted = new HashMap<String, Double>();
			map_to_be_sorted.put("A", 99.0);
			map_to_be_sorted.put("B", 30.1);
			map_to_be_sorted.put("E", null); 
			map_to_be_sorted.put("C", 107.3);
	     
	       /**
	        * Initialize the `map' in class @HeapSort with `map_to_be_sorted' by call method @setMap;
	        * Method @setMap throws MapContainsNullValueException, when the values in the map contain @null.
	        */
			heapsort.setMap(map_to_be_sorted);	    
	    }
	
	    @Test(expected = MapContainsNullValueException.class)
	    public void test_heap_exception2(){
		 Map<String, Double> map_to_be_sorted = new HashMap<String, Double>();
			map_to_be_sorted.put("man", null);
			map_to_be_sorted.put("woman", 9.6);
			map_to_be_sorted.put("Karen", null); 
	     
	       /**
	        * Initialize the `map' in class @HeapSort with `map_to_be_sorted' by call method @setMap;
	        * Method @setMap throws MapContainsNullValueException, when the values in the map contain @null.
	        */
			heapsort.setMap(map_to_be_sorted);
	    }
	    @Test
	    public void test_heap_basic2() {
		Map<String, Double> map_to_be_sorted = new HashMap<String, Double>();
		map_to_be_sorted.put("asus", 29.2);
		map_to_be_sorted.put("zotac", 45.2);
		map_to_be_sorted.put("gigabyte", 51.7);
		map_to_be_sorted.put("founder", 9.03); 
		map_to_be_sorted.put("pny", 47.2);
	    
	    /**
	     * Initialize the `map' in bubble with `map_to_be_sorted';
	     */
	    heapsort.setMap(map_to_be_sorted);    
	    
	    /**
	     * Expected results: the order of keys after ranking `map' by value with max heap algorithm;
	     */
		ArrayList<String> results = new ArrayList<String>();
		results.add("founder");
		results.add("asus");
		results.add("zotac");
		results.add("pny");
		results.add("gigabyte");
		
		/**
		 * map size should be the same;
		 */
		Assert.assertEquals(map_to_be_sorted.size(), heapsort.getMap().size());
		/**
		 * Expected result should have the same size of the ranked key list;
		 */
	    Assert.assertEquals(results.size(), heapsort.sortbyValue().size());
	    
	    /**
	     * Elements in the same position from the expected result and the ranked key list should the same;
	     */
		for(int i =0; i<results.size(); i++) {
			 Assert.assertEquals(results.get(i), heapsort.sortbyValue().get(i));
		}
	 }
	
	    @Test
	    public void test_heap_basic3() {
		Map<String, Double> map_to_be_sorted = new HashMap<String, Double>();
		map_to_be_sorted.put("mom", 1.0);
		map_to_be_sorted.put("me", 99.2);
		map_to_be_sorted.put("brother", 69.03); 
		map_to_be_sorted.put("dad", 3.0);
		map_to_be_sorted.put("sister", 70.0);
	    
	    /**
	     * Initialize the `map' in bubble with `map_to_be_sorted';
	     */
	    heapsort.setMap(map_to_be_sorted);    
	    
	    /**
	     * Expected results: the order of keys after ranking `map' by value with max heap algorithm;
	     */
		ArrayList<String> results = new ArrayList<String>();
		results.add("mom");
		results.add("dad");
		results.add("brother");
		results.add("sister");
		results.add("me");
		
		/**
		 * map size should be the same;
		 */
		Assert.assertEquals(map_to_be_sorted.size(), heapsort.getMap().size());
		/**
		 * Expected result should have the same size of the ranked key list;
		 */
	    Assert.assertEquals(results.size(), heapsort.sortbyValue().size());
	    
	    /**
	     * Elements in the same position from the expected result and the ranked key list should the same;
	     */
		for(int i =0; i<results.size(); i++) {
			 Assert.assertEquals(results.get(i), heapsort.sortbyValue().get(i));
		}
	 }
	
	
}
