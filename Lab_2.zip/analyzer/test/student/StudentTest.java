package student;
import java.util.ArrayList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import graph.DGraph;
import graph.Edge;
import graph.ListDGraph;

import org.junit.Assert;

public class StudentTest {
 /**
  * TODO: 
  * 	write at least 20 Junit test cases to test your implementation of ListDGraph;
  */
	
	 DGraph<String> graph = new ListDGraph<String>();
	 DGraph<String> graph2 = new ListDGraph<String>();
	 DGraph<String> graph3 = new ListDGraph<String>();
	 
	 @Before
		public void setUp() throws Exception {
		 	graph.addV("4");
	        graph.addV("3");
	        graph.addV("2");
	        graph.addV("1");
	        
	        graph2.addV("4");
	        graph2.addV("3");
	        graph2.addV("2");
	        graph2.addV("1");
	        graph2.addV("5");
	        
	        graph3.addV("4");
	        graph3.addV("3");
	        graph3.addV("2");
	        graph3.addV("1");
	        graph3.addV("5");
	        graph3.addV("6");
	        
	        graph.addE(new Edge<String>("1", "2"));
	        graph.addE(new Edge<String>("1", "3"));
	        graph.addE(new Edge<String>("2", "3"));
	        graph.addE(new Edge<String>("2", "4"));
	        
	        graph2.addE(new Edge<String>("3", "4"));
	        graph2.addE(new Edge<String>("1", "2"));
	        graph2.addE(new Edge<String>("2", "3"));
	        graph2.addE(new Edge<String>("2", "4"));
	        graph2.addE(new Edge<String>("7", "4"));
		}
	
	 @Test
	 public void test_matrix1() {
			/**
			 * genearate the matrix
			 */
			int [][] matrix = graph.matrix();
			
			/**
			 * expected matrix `m`
			 */
			int m [][] = new int[4][4];
	    	 m[1][0] =0; m[0][1] =1; m[0][2] =1; m[0][3] =0;
	    	 m[2][0] =0; m[1][1] =0; m[1][2] =1; m[1][3] =1;
	    	 m[3][0] =0; m[2][1] =0; m[2][2] =0; m[2][3] =0;
	    	 m[3][0] =0; m[3][1] =0; m[3][2] =0; m[3][3] =0;
	    	 
	    	System.out.println(m.toString());
	    	
	        Assert.assertEquals(matrix.length, m.length);
	     }
	 
	 
	 @Test
	 public void test_matrix2() {
			/**
			 * generate the matrix
			 */
			int [][] matrix = graph2.matrix();
			
			/**
			 * expected matrix `m`
			 */
			int m [][] = new int[5][5];
	    	 m[1][0] =0; m[0][1] =1; m[0][2] =1; m[0][3] =0;
	    	 m[2][0] =0; m[1][1] =0; m[1][2] =1; m[1][3] =1;
	    	 m[3][0] =0; m[2][1] =0; m[2][2] =0; m[2][3] =0;
	    	 m[3][0] =0; m[3][1] =0; m[3][2] =0; m[3][3] =0;
	    	 m[1][0] =0; m[3][1] =0; m[3][2] =0; m[3][3] =0;
	    	 
	    	System.out.println(m.toString());
	    	
	        Assert.assertEquals(matrix.length, m.length);
	     }
	
	 @Test
	 public void test_matrix3() {
			/**
			 * generate the matrix
			 */
			int [][] matrix = graph3.matrix();
			
			/**
			 * expected matrix `m`
			 */
			int m [][] = new int[6][6];
	    	 m[5][0] =0; m[0][1] =1; m[0][2] =1; m[0][3] =0;
	    	 m[4][0] =0; m[1][1] =0; m[1][2] =1; m[1][3] =1;
	    	 m[3][0] =0; m[3][1] =0; m[0][2] =0; m[2][3] =0;
	    	 m[3][0] =0; m[3][1] =0; m[3][2] =0; m[3][3] =0;
	    	 m[1][0] =0; m[3][1] =0; m[3][2] =0; m[3][3] =0;
	    	 m[5][0] =0; m[0][1] =1; m[0][2] =1; m[0][3] =0;
	    	System.out.println(m.toString());
	    	
	        Assert.assertEquals(matrix.length, m.length);
	     }
	 
	 @Test
	    public void test_addE() { 

			Edge<String> e = new Edge<String>("1", "2");
			/**
			 * add an exist edge
			 */
			boolean success = graph.addE(e);
			Assert.assertEquals(false, success);
			
			/**
			 * add a new edge
			 */
			Edge<String> e1 = new Edge<String>("1", "4");
			success = graph.addE(e1);
			Assert.assertEquals(true, success);
	     }
	 
	 @Test
	 	public void test_addE2() {
		 Edge<String> e = new Edge<String>("1", "3");
		 boolean success = graph.addE(e);
		Assert.assertEquals(false, success);
		Edge<String> e2 = new Edge<String>("1", "2");
		success = graph.addE(e2);
		Assert.assertEquals(false, success);
	 }
	 
	 @Test
	 	public void test_addE3() {
		 Edge<String> e = new Edge<String>("2", "4");
		 boolean success = graph2.addE(e);
		Assert.assertEquals(false, success);
		Edge<String> e2 = new Edge<String>("5", "7");
		success = graph2.addE(e2);
		Assert.assertEquals(false, success);
	 }
	 
	 @Test
	 	public void test_addE4() {
		 Edge<String> e = new Edge<String>("7", "4");
		 boolean success = graph2.addE(e);
		Assert.assertEquals(false, success);
		Edge<String> e2 = new Edge<String>("3", "2");
		success = graph2.addE(e2);
		Assert.assertEquals(false, success);
	 }
	 
	 @Test
	    public void test_removeE() { 
			Edge<String> e1 = new Edge<String>("2", "4");
			graph.addE(e1);
		
			Edge<String> e2 = graph.removeE(new Edge<String>("2", "4"));
			
	        Assert.assertEquals(true, e1.equals(e2));
	     }
	 
	 @Test
	    public void test_removeE2() { 
			Edge<String> e1 = new Edge<String>("2", "4");
			graph.addE(e1);
		
			Edge<String> e2 = graph.removeE(new Edge<String>("3", "4"));
			
	        Assert.assertEquals(false, e1.equals(e2));
	     }
	 
	 @Test
	    public void test_removeE3() { 
			Edge<String> e1 = new Edge<String>("3", "4");
			graph2.addE(e1);
		
			Edge<String> e2 = graph2.removeE(new Edge<String>("2", "4"));
			
	        Assert.assertEquals(false, e1.equals(e2));
	     }
	 
	 @Test
	    public void test_removeV() { 
	    	String v = graph.removeV("4");
	        Assert.assertEquals("4", v);
	     }
	 @Test
	    public void test_removeV2() { 
	    	String v = graph.removeV("3");
	        Assert.assertEquals("3", v);
	     }
	 @Test
	    public void test_removeV3() { 
	    	String v = graph.removeV("3");
	        Assert.assertEquals("3", v);
	     }
	 @Test
	    public void test_removeV4() { 
	    	String v = graph.removeV("1");
	        Assert.assertEquals("1", v);
	     }
	 @Test
	    public void test_addV() { 
			/**
			 * add an exist V
			 */
			int index = graph.addV("2");
			Assert.assertEquals(-1, index);
			
			/**
			 * add a new V
			 */
			index = graph.addV("9");
			Assert.assertEquals(5, index);
	     }
	 @Test
	    public void test_addV2() { 
			/**
			 * add an exist V
			 */
			int index = graph.addV("1");
			Assert.assertEquals(-1, index);
			
			/**
			 * add a new V
			 */
			index = graph.addV("11");
			Assert.assertEquals(5, index);
	     }
	 
	 @Test
	    public void test_addV3() { 
			/**
			 * add an exist V
			 */
			int index = graph.addV("3");
			Assert.assertEquals(-1, index);
			
			/**
			 * add a new V
			 */
			index = graph.addV("10");
			Assert.assertEquals(5, index);
	     }
	 
	 @Test
	    public void test_branches() { 
	        //Iterate the graph from V "1"
	    	ArrayList<ArrayList<String>> bs;
	    	bs = graph.branches("1");
	        
	    	ArrayList<ArrayList<String>> expected = new ArrayList<ArrayList<String>>();
	    	ArrayList<String> b1 = new ArrayList<String>();
	    	b1.add("1"); b1.add("2"); b1.add("4"); 
	    	
	    	ArrayList<String> b2 = new ArrayList<String>();
	    	b2.add("1"); b2.add("2"); b2.add("3"); 
	    	
	    	ArrayList<String> b3 = new ArrayList<String>();
	    	b3.add("1"); b3.add("3"); 
	    	
	    	expected.add(b1);
	    	expected.add(b2);
	    	expected.add(b3);
	    	
	        Assert.assertEquals(bs.size(), expected.size());
	     }
	 
	 @Test
	    public void test_branches2() { 
	        //Iterate the graph from V "1"
	    	ArrayList<ArrayList<String>> bs;
	    	bs = graph.branches("1");
	        
	    	ArrayList<ArrayList<String>> expected = new ArrayList<ArrayList<String>>();
	    	ArrayList<String> b1 = new ArrayList<String>();
	    	b1.add("1"); b1.add("2"); b1.add("4"); 
	    	
	    	ArrayList<String> b2 = new ArrayList<String>();
	    	b2.add("1"); b2.add("2"); b2.add("3"); 
	    	
	    	ArrayList<String> b3 = new ArrayList<String>();
	    	b3.add("1"); b3.add("3"); 
	    	
	    	expected.add(b1);
	    	expected.add(b2);
	    	expected.add(b3);
	    	
	        Assert.assertEquals(bs.size(), expected.size());
	     }
	 @Test
	    public void test_branches3() { 
	        //Iterate the graph from V "1"
	    	ArrayList<ArrayList<String>> bs;
	    	bs = graph.branches("1");
	        
	    	ArrayList<ArrayList<String>> expected = new ArrayList<ArrayList<String>>();
	    	ArrayList<String> b1 = new ArrayList<String>();
	    	b1.add("1"); b1.add("2"); b1.add("4"); 
	    	
	    	ArrayList<String> b2 = new ArrayList<String>();
	    	b2.add("1"); b2.add("2"); b2.add("3"); 
	    	
	    	ArrayList<String> b3 = new ArrayList<String>();
	    	b3.add("1"); b3.add("3"); 
	    	
	    	expected.add(b1);
	    	expected.add(b2);
	    	expected.add(b3);
	    	
	        Assert.assertEquals(bs.size(), expected.size());
	     }
}
