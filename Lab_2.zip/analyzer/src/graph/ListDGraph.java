package graph;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Use LinkedList to implement the directed graph
 * @param <V>
 * @author wangs and you
 */
public class ListDGraph<V> implements DGraph<V>{
   
	
    /**list of the vertices in a graph*/
    private LinkedList<Vertex<V>> vList;
   
    
    /**
     * constructor
     */
    public ListDGraph() {
        vList = new LinkedList<Vertex<V>>();
    }
    
    @Override
    public int addV(V v) {
      /**
       * TODO: implement the addV function;
       */
    	int index = 1;
        for(Vertex<V> i: vList) {
        	if(i.getV() == v) {
        		return -1;
        		
        	}
        	index++;
        }
        
        vList.addLast(new Vertex<V>(v));
        return index;
    }

    
    @Override
    public boolean addE(Edge<V> e) {
    	/**
        * TODO: implement the addE function;
        */
    	V s = e.getSource();
    	V d = e.getDest();
    	boolean s_Check = false;
        boolean d_Check = false;
        
    	Vertex<V> src = new Vertex<V>(s);
    	Vertex<V> dest = new Vertex<V>(d);
    	
    	
    	
    	for(Vertex<V> vertex : vList) {
    		if(vertex.getV() == s) {
    			src = vertex;
    			for(Edge<V> edge: vertex.getEdgeList()) {
    				if(edge.equals(e)) {
    					return false;
    				}
    			}
    		}
    	}
    	
          for (Vertex<V> vertex : vList) {
        	  if (vertex.equals(src))
      			s_Check = true;
      		
      		  if (vertex.equals(dest))
      			d_Check = true;
          }
          
          if (!s_Check || !d_Check) {
              return false;
          }
    
          src.addEdge(e);

          return true;
    }
    
    
    @Override
    public V removeV(V v) {
    	/**
         * TODO: implement the removeV function;
         */
    	
    	for (Vertex<V> v1 : vList) {
    		if (v1.getV() == v) {
    			for(Vertex<V> v2: vList) {
    				for (Edge<V> edge: v2.getEdgeList() ) {
    					if(edge.getSource()== v || edge.getDest() == v) {
    						v2.getEdgeList().remove(edge);
    					}
    				}
    				vList.remove(v1);
    				return v1.getV();
    			}
    		}
    	}
    	 return null;
    }

    @Override
    public Edge<V> removeE(Edge<V> e) {
    	/**
         * TODO: implement the removeE function;
         */
    	  
    	for(Vertex<V> vertex : vList) {
    		if(vertex.getV() == e.getSource() ) {
    			vertex.getEdgeList().remove(e);
    			return e;
    		}
    	}
    	return null;
    }

    @Override
    public V getV(int index) {
    	/**
         * TODO: implement the getV function;
         */
    	int v = 1 ;
    	for(Vertex<V> vertex : vList) {
    		if (v == index) {
    			return vertex.getV();
    		}
    		v++;
    	}
    	return null;
    }

    @Override
    public Edge<V> getE(int src, int dest) {
    	/**
         * TODO: implement the getE function;
         */
    	 Edge<V> ret = null;
         V s = getV(src);
         V d = getV(dest);
         
         for (Vertex<V> vertex : vList) {
        	 if(vertex.getV() == s) {
        		 for (Edge<V> edge: vertex.getEdgeList()) {
        			 if(edge.getDest() == d) {
        				 return edge;
        			 }
        		 }
        	 }
         }
         return ret;
    }

	@Override
	public ArrayList<ArrayList<V>> branches(V v) {
		/**
		 * TODO: iterate the Graph from a given vertex and return all the branches from it;
		 */
		Vertex<V> current = new Vertex<V>(v);
		for(Vertex<V> vertex: vList) {
			if(vertex.getV()== v) {
				current = vertex;
				break;
			}
		}
		
		ArrayList<ArrayList<V>> result = new ArrayList<>();
		List<Edge<V>> edges = current.getEdgeList();
		ArrayList<V> list = new ArrayList<>();
		list.add(v);
		
		if(edges.size()==0) {
			result.add(list);
			return result;
		}
			
		current.setVisitedStatus(true);
		
		 for (int i = 0; i < edges.size(); i++) {
			 
			 V dest = edges.get(i).getDest();
			 
			 
			 if(dest !=null && !visitedStatus(dest)){
				 
				 
				 ArrayList<ArrayList<V>> dest2 = branches(dest);
				 int len = dest2.size();
				 
				 for (int j = 0; j < len; j++) {
					 list.addAll(dest2.get(j));
					 result.add(list);
				 }
			 }
		 }
		 
		 return result;
		
		 
		}
	

	
	public boolean visitedStatus(V v) {
    Vertex<V> vert = new Vertex<V>(v);
    for (Vertex<V> ver : vList) {
        if (ver.getV() == v) 
            vert = ver;
    }

    return vert.getVisitedStatus();
	}
	
	
    @Override
    public int [][] matrix() {
    	/**
    	 * TODO: generate the adjacency matrix of a graph;
    	 */
    	int len = vList.size();
    	int[][] result = new int[len][len];
    	for( int i = 0; i < len; i++) {
    		for( int j = 0; j < len; j++) {
    			if (getE(i,j) != null) {
    			result[i][j] = 1;
    		}
    		else {
    			result[i][j] = 0 ;
    		}
    	}
    	}
    			return result;
    }
}